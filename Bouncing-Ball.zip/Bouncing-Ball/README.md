# Bouncing-Ball

Bouncing-Ball is a console-based simulator designed for terminal.app. It is a simulator for a ball or other bouncing object like light. Using the menu, you can specify the ball's angle in the next simulation run. and even the simulation speed.

## Using

1. Download the Bouning-Ball .zip and extract its contents.
2. Double-click the .exec file to run.

## Versions

* 1.0 - The first release

## Authors

* Morgan Shimp

## License

This program is licensed under an MIT License. View the LICENSE.md file for details.
